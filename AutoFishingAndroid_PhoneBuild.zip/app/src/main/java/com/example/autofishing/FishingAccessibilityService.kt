package com.example.autofishing

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityService.ScreenshotResult
import android.accessibilityservice.GestureDescription
import android.graphics.Bitmap
import android.graphics.Path
import android.graphics.PixelFormat
import android.media.Image
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import com.google.mlkit.vision.text.korean.KoreanTextRecognizerOptions
import java.nio.ByteBuffer
import java.util.concurrent.atomic.AtomicBoolean

class FishingAccessibilityService : AccessibilityService() {
    private val handler = Handler(Looper.getMainLooper())
    private val busy = AtomicBoolean(false)
    private val latin by lazy { TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS) }
    private val korean by lazy { TextRecognition.getClient(KoreanTextRecognizerOptions.Builder().build()) }
    private var mode = Mode.WAITING
    private var lastAction = 0L
    private var tapUntil = 0L
    private enum class Mode { WAITING, CAST_WAIT, TAPPING, RESULT_WAIT }
    private val loop = object : Runnable {
        override fun run() {
            val prefs = getSharedPreferences("fishing", MODE_PRIVATE)
            if (!prefs.getBoolean("running", false)) {
                mode = Mode.WAITING
                handler.postDelayed(this, 700)
                return
            }
            if (Build.VERSION.SDK_INT >= 30 && busy.compareAndSet(false, true)) {
                takeScreenshot(0, mainExecutor, object : TakeScreenshotCallback {
                    override fun onSuccess(result: ScreenshotResult) {
                        try {
                            val hw = result.hardwareBuffer
                            val hardwareBitmap = Bitmap.wrapHardwareBuffer(hw, result.colorSpace)
                            val bitmap = hardwareBitmap?.copy(Bitmap.Config.ARGB_8888, false)
                            hardwareBitmap?.recycle()
                            hw.close()
                            if (bitmap != null) inspect(bitmap) else busy.set(false)
                        } catch (_: Exception) {
                            busy.set(false)
                        }
                    }
                    override fun onFailure(errorCode: Int) { busy.set(false) }
                })
            }
            handler.postDelayed(this, 450)
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        handler.post(loop)
    }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() { getSharedPreferences("fishing", MODE_PRIVATE).edit().putBoolean("running", false).apply() }

    private fun inspect(bitmap: Bitmap) {
        val image = InputImage.fromBitmap(bitmap, 0)
        latin.process(image).addOnSuccessListener { latinText ->
            korean.process(image).addOnSuccessListener { koreanText ->
                val all = (latinText.text + " " + koreanText.text).lowercase()
                val now = System.currentTimeMillis()
                val prefs = getSharedPreferences("fishing", MODE_PRIVATE)
                val fastPrompt = all.contains("빠르게") || all.contains("tap") || all.contains("click")
                when {
                    fastPrompt -> {
                        if (mode != Mode.TAPPING) tapUntil = now + 5000
                        mode = Mode.TAPPING
                        val x = prefs.getInt("tapX", 50) / 100f
                        val y = prefs.getInt("tapY", 78) / 100f
                        tap(bitmap.width * x, bitmap.height * y, 65)
                    }
                    mode == Mode.TAPPING -> {
                        mode = Mode.RESULT_WAIT
                        lastAction = now
                    }
                    all.contains("perfect") && mode != Mode.RESULT_WAIT -> {
                        mode = Mode.RESULT_WAIT
                        lastAction = now
                    }
                    mode == Mode.WAITING || (mode == Mode.RESULT_WAIT && now - lastAction > 2500) -> {
                        if (now - lastAction > 1800) {
                            val x = prefs.getInt("castX", 50) / 100f
                            val y = prefs.getInt("castY", 55) / 100f
                            tap(bitmap.width * x, bitmap.height * y, 90)
                            mode = Mode.CAST_WAIT
                            lastAction = now
                        }
                    }
                    mode == Mode.CAST_WAIT && now - lastAction > 9000 -> {
                        mode = Mode.WAITING
                        lastAction = now
                    }
                }
                bitmap.recycle()
                busy.set(false)
            }.addOnFailureListener { bitmap.recycle(); busy.set(false) }
        }.addOnFailureListener { bitmap.recycle(); busy.set(false) }
    }

    private fun tap(x: Float, y: Float, duration: Long) {
        val path = Path().apply { moveTo(x, y) }
        val stroke = GestureDescription.StrokeDescription(path, 0, duration)
        val gesture = GestureDescription.Builder().addStroke(stroke).build()
        dispatchGesture(gesture, null, null)
    }
    override fun onDestroy() {
        handler.removeCallbacks(loop)
        latin.close(); korean.close()
        super.onDestroy()
    }
}
