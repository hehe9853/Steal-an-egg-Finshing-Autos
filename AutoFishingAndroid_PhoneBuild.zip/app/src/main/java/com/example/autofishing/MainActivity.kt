package com.example.autofishing

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.EditText
import android.view.Gravity
import android.view.ViewGroup

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("fishing", MODE_PRIVATE) }
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (18 * resources.displayMetrics.density).toInt()
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
            gravity = Gravity.CENTER_HORIZONTAL
        }
        status = TextView(this).apply { textSize = 16f }
        layout.addView(TextView(this).apply {
            text = "자동 낚시 설정"
            textSize = 24f
        })
        layout.addView(TextView(this).apply {
            text = "1) 접근성 권한을 켠 뒤 로블록스 게임으로 돌아가세요.\n" +
                "2) 낚시 화면은 가로 모드 기준입니다.\n" +
                "3) 시작 후 화면 인식이 맞지 않으면 아래 터치 위치를 조정하세요.\n\n" +
                "※ 화면 인식과 터치 자동화는 게임 업데이트·화면 배율에 따라 정확도가 달라질 수 있습니다."
            textSize = 14f
        })
        val enable = Button(this).apply {
            text = "접근성 설정 열기"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        }
        layout.addView(enable, match())
        layout.addView(TextView(this).apply { text = "찌 던지기 터치 위치 (%)  (기본 50, 55)" })
        val castX = EditText(this).apply { setSingleLine(); hint = "가로 X: 50"; setText(prefs.getInt("castX", 50).toString()) }
        val castY = EditText(this).apply { setSingleLine(); hint = "세로 Y: 55"; setText(prefs.getInt("castY", 55).toString()) }
        layout.addView(castX, match()); layout.addView(castY, match())
        layout.addView(TextView(this).apply { text = "빠른 탭 위치 (%)  (기본 50, 78)" })
        val tapX = EditText(this).apply { setSingleLine(); hint = "가로 X: 50"; setText(prefs.getInt("tapX", 50).toString()) }
        val tapY = EditText(this).apply { setSingleLine(); hint = "세로 Y: 78"; setText(prefs.getInt("tapY", 78).toString()) }
        layout.addView(tapX, match()); layout.addView(tapY, match())
        val save = Button(this).apply {
            text = "위치 저장"
            setOnClickListener {
                prefs.edit()
                    .putInt("castX", castX.value(50)).putInt("castY", castY.value(55))
                    .putInt("tapX", tapX.value(50)).putInt("tapY", tapY.value(78)).apply()
                status.text = "위치 저장 완료"
            }
        }
        layout.addView(save, match())
        val start = Button(this).apply {
            text = "자동 낚시 시작"
            setOnClickListener { prefs.edit().putBoolean("running", true).apply(); status.text = "실행 요청됨 — 로블록스 화면으로 돌아가세요." }
        }
        val stop = Button(this).apply {
            text = "정지"
            setOnClickListener { prefs.edit().putBoolean("running", false).apply(); status.text = "정지됨" }
        }
        layout.addView(start, match()); layout.addView(stop, match())
        layout.addView(status, match())
        setContentView(layout)
        status.text = if (prefs.getBoolean("running", false)) "실행 상태가 저장되어 있습니다." else "대기 중"
    }
    private fun match() = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
    private fun EditText.value(fallback: Int): Int = text.toString().toIntOrNull()?.coerceIn(0,100) ?: fallback
}
